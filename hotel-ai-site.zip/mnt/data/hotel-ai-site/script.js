function startProcess() {
  const input = document.getElementById('fileInput');
  const result = document.getElementById('result');
  const count = input.files.length;

  if (!count) {
    result.classList.remove('hidden');
    result.innerHTML = '<strong>Lütfen önce fotoğraf seç.</strong>';
    return;
  }

  const rejected = Math.max(1, Math.round(count * 0.18));
  const selected = Math.max(1, count - rejected);
  const bw = Math.min(10, Math.max(5, Math.round(selected * 0.12)));
  const beach = Math.min(10, Math.max(5, Math.round(selected * 0.10)));

  result.classList.remove('hidden');
  result.innerHTML = `
    <h3>AI İşleme Raporu</h3>
    <p>Yüklenen fotoğraf: <b>${count}</b></p>
    <p>Silinecek düşük kalite fotoğraf: <b>${rejected}</b></p>
    <p>Editlenecek seçili fotoğraf: <b>${selected}</b></p>
    <p>Siyah-beyaz yakın kadraj: <b>${bw}</b></p>
    <p>Sahil gölge efektli fotoğraf: <b>${beach}</b></p>
    <p><b>Durum:</b> Demo tamamlandı. Gerçek AI için backend + Photoshop/Lightroom API bağlanmalı.</p>
  `;
}
